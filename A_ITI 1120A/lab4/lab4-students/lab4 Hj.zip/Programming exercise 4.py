for i in range(11):
    print(" "*(11-i),end="")
    print("#"*(2*i-1))
