def prog_solved_v1():
     name = input("What is your name? ")
     age = int(input("How old are you? "))
     if age<18:
          print(name, ", you are", age, "years old, and thus underage and ineligible to vote")
     else:
          print(name, ", you are", age, "years old, and thus eligible to vote")
     return

