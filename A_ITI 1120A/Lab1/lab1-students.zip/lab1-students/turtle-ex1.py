import turtle
s=turtle.Screen()
t=turtle.Turtle()

# Place your code after this line

